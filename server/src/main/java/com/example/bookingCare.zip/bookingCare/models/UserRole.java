package com.example.bookingCare.models;

public enum UserRole {
    DOCTOR,
    ADMIN
}
